"""Streaming integrations (Kafka)."""
