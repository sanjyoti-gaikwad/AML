"""MCP capability manifest stubs."""
