"""Synthetic data generators."""
